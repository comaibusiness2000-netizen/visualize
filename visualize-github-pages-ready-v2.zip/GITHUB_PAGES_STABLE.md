# Link stabile con GitHub Pages

Questa opzione crea un link permanente tipo:

`https://TUO-NOME.github.io/visualize-app/`

## Passaggi

1. Crea o apri un account GitHub.
2. Crea un nuovo repository chiamato `visualize-app`.
3. Carica tutti i file di questa cartella nel repository.
4. Vai su `Settings` -> `Pages`.
5. In `Build and deployment`, scegli `GitHub Actions`.
6. Vai su `Actions`.
7. Apri `Deploy Visualize Preview`.
8. Avvia o attendi il deploy.

Quando il deploy finisce, GitHub mostra il link pubblico.

## Aggiornamenti automatici

Ogni volta che carichi modifiche su GitHub nel branch `main`, la workflow aggiorna automaticamente lo stesso link.

## iPhone

1. Apri il link in Safari.
2. Tocca Condividi.
3. Tocca Aggiungi alla schermata Home.
4. Conferma Aggiungi.

L'icona rimane stabile e punta sempre allo stesso link.
